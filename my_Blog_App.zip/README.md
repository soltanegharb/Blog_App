# Blog_App
a blog application that authors can post their blogs and readers can read blogs
